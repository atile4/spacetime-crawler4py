import re
import json
import os

from urllib.parse import urlparse
from urllib.parse import urljoin
from urllib.parse import urldefrag

from bs4 import BeautifulSoup, UnicodeDammit

from text_processing import computeWordFrequencies, tokenize
from page_filters import is_trap, low_value_reason

from urllib.robotparser import RobotFileParser
import threading

class Report:
    def __init__(self): 
        self.visited_urls = set()
        self.longest_webpage = ('', -1)
        self.token_frequency_table = dict()
        self.url_subdomain_count = dict()
        self._robot_rules = dict()
        self._lock = threading.Lock()        # guards the stats
        self._robot_lock = threading.Lock()  # guards the robots cache
        self._save_lock = threading.Lock() # guards file saving

    def save_report(self, file_name="report_files/report.json"):
        # save the data we want into a dictionary
        with self._save_lock:
            with self._lock:
                data = {
                    "visited": list(self.visited_urls),
                    "long": self.longest_webpage,
                    "token": self.token_frequency_table.copy(),
                    "subdomain": dict(sorted(self.url_subdomain_count.items())) # sorting in json file for me purposes
                }
            # temporarily creating a file name so we don't overwrite old data
            temp = file_name + '.tmp'
            # open the temporary file in write mode
            with open(temp, "w", encoding="utf-8") as file:
                # write dict into temp file for crashes
                json.dump(data, file, indent=2)
            # replace the old json file with the temporary one
            os.replace(temp, file_name)

        
    def load_report(self, file_name="report_files/report.json"):
        # if file not found
        if not os.path.exists(file_name):
            return
        # open json file in read mode
        with open(file_name, "r", encoding="utf-8") as file:
            # getting data 
            data = json.load(file)
        # check if our dictionary is empty
        if not data:
            return
        with self._lock:
            # restoring data
            self.visited_urls = set(data["visited"])
            self.longest_webpage = tuple(data["long"])
            self.token_frequency_table = dict(data["token"])
            self.url_subdomain_count = {}
            for key, count in data["subdomain"].items():
                hostname = urlparse(key).hostname if "://" in key else key 

                if hostname:
                    self.url_subdomain_count[hostname] = (
                        self.url_subdomain_count.get(hostname, 0) + count
                    )


    def _print_report(self):
        # formatting subdomains correctly 
        sub_domains = []
        for host_name, count in self.getURLSubdomainCount():
            sub_domains.append(f"http://{host_name}, {count}")
        sub_domains_text = "\n".join(sub_domains)

        return(
            f"============REPORT============\n"
            f"unique pages: {self.getNumVisitedURLs()}\n"
            f"longest page: {self.getLongestWebpage()}\n"
            f"top 50 words: {self.getMostCommonWords()}\n"
            f"subdomain count: \n{sub_domains_text}")


    def isAllowedByRobots(self, url, fetch, user_agent='*') -> bool:
        parts = urlparse(url)
        robot_url = f"{parts.scheme}://{parts.netloc}/robots.txt"
        with self._robot_lock:  # one fetch per host, others wait briefly
            rp = self._robot_rules.get(robot_url)
            if rp is None:
                rp = self._buildParser(robot_url, fetch)
                self._robot_rules[robot_url] = rp   # cached even on failure
        return rp.can_fetch(user_agent, url)


    def _buildParser(self, robot_url, fetch):
        rp = RobotFileParser(robot_url)
        resp = fetch(robot_url)
        if resp is not None and resp.status == 200 and resp.raw_response is not None:
            text = resp.raw_response.content.decode("utf-8", errors="ignore")
            rp.parse(text.splitlines())
        elif resp is not None and resp.status in (401, 403):
            rp.parse(["User-agent: *", "Disallow: /"])
        else:                       # no response, 404, 5xx, etc.
            rp.parse(["User-agent: *", "Allow: /"])
        return rp


    def visitSite(self, url, soup):
        ICS_DOMAIN = re.compile(r"^(?:[a-z0-9-]+\.)*ics\.uci\.edu$")

        tokens = tokenize(soup.get_text(" ", strip=True))
        token_freq = computeWordFrequencies(tokens=tokens)
        parsed = urlparse(url)

        with self._lock:
            if url in self.visited_urls: return
            self.visited_urls.add(url)
            self._updateWordFrequencies(token_freq)
            self._checkIfLongestPage(url, len(tokens))

            if ICS_DOMAIN.match(parsed.hostname): # only incrementing for ics.uci.edu domain
                self._incrementSubdomainCount(parsed.hostname)
            


    def getNumVisitedURLs(self) -> int:
        return len(self.visited_urls)


    def getLongestWebpage(self):
        return self.longest_webpage


    def getMostCommonWords(self, count = 50) -> list[tuple[str, int]]:
        # returns most common words as a sorted list of tuples by frequency
        return sorted(self.token_frequency_table.items(),
            key=lambda item: (-item[1], item[0]))[:count]


    def getURLSubdomainCount(self) -> list[tuple[str, int]]:
        # returns subdomains as a sorted list of tuples in alphabetical order
        return sorted(self.url_subdomain_count.items())


    def _updateWordFrequencies(self, map: dict[str, int]) -> None:
        for token, freq in map.items():
            self.token_frequency_table[token] = self.token_frequency_table.get(token, 0) + freq

    
    def _incrementSubdomainCount(self, base_url: str):
        if base_url in self.url_subdomain_count:
            self.url_subdomain_count[base_url] += 1
        else:
            self.url_subdomain_count[base_url] = 1    

        
    def _checkIfLongestPage(self, url: str, tokens_count: int):
        if self.longest_webpage[1] < tokens_count:
            self.longest_webpage = (url, tokens_count)


    def _urlAllowedByRobotTxt(self, url : str, base_url: str, user_agent = '*') -> bool:
        """
        Returns if string is valid and is not disallowed in the base_url's robots.txt
        """
        robot_url = f'{base_url}/robots.txt'
        # Read and parse robots.txt
        if robot_url in self._robot_rules:
            return self._robot_rules[robot_url].can_fetch(user_agent, url)

        rp = RobotFileParser(robot_url)
        try:
            rp.read()
        except Exception as e:
            # return True on error; no robots.txt to deny entry
            print(f'Returned True after exception encountered accessing robots.txt of {base_url}:', e)
            return True

        # @TODO potential optimization:
        # store disallowed urls in a dictionary that maps str base urls to a set of their disallowed urls

        # check if url is allowed
        self._robot_rules[robot_url] = rp
        return rp.can_fetch(user_agent, url) 

def scraper(url, report : Report, resp) -> list[str]: 
    # check whether response is sucessful or if there is no content -> if not return
    if resp.status != 200 or resp.raw_response is None: return []

    # getting the absolute finalurl for handling redirects
    final_url = resp.raw_response.url or url
    absolute_url = urldefrag(final_url).url

    # check if the redirect destination is a valid url and get the status of whether its a trap
    if not is_valid(absolute_url): return []
    current_is_trap = is_trap(absolute_url)

    # check whether this isn't an image or any other type with no info
    content_type = resp.raw_response.headers.get("Content-Type", "").lower()
    if "text/html" not in content_type: return [] 

    # get data of site
    raw_content = resp.raw_response.content

    # decode the downloaded html before parsing it, we want to identify correct encoding 
    if raw_content.startswith(b'\xff\xfe') or raw_content.startswith(b'<\x00h\x00t\x00m\x00l\x00'):
        html = raw_content.decode("utf-16-le")
    else:
        decoded = UnicodeDammit(raw_content, is_html=True)
        html = decoded.unicode_markup

    if html is None: # if it couldnt be decoded then we can't reference this site
        print(f"Skipped {absolute_url}: unable to decode HTML")
        return []

    # our frontier is only going to get valid and known non-traps 
    soup = BeautifulSoup(html, "html.parser") 
    links = extract_next_links(absolute_url, soup)
    valid_links = [link for link in links if is_valid(link) and not is_trap(link)]

    # get the content of the link we're currently on -> try to get the article text -> if theres no article tag then get ALL text
    article_content = (soup.article.get_text(" ", strip=True) if soup.article else soup.get_text(" ", strip=True))
    reason = low_value_reason(resp, article_content)

    if reason: # skip 
        print(f"Skipped {absolute_url}: {reason}")
    elif current_is_trap: # if it was a trap from earlier, we're gonna skip 
        print(f"Skipped reporting {absolute_url}: trap URL")
    else:
        report.visitSite(absolute_url, soup) # mark visit

    return valid_links

def extract_next_links(url, soup):
    """
    extracts all the links found in the webpage to be returned 
    Inputs:
        url(string) - full absolute url used to get the page
    Outputs:
        hyper_links(list) - list of drafragmented links found in webpage
    """
    # goal: return a list with ALL hyperlinks -> valid or not
    # create a list
    hyper_links = []

    # parse the content -> accquire the links
    for link in soup.find_all('a', href=True):
        temp = link.get('href')
        # if empty skip to the next link
        if not temp or not temp.strip(): 
            continue
        # appending links to list, joining links so relative becomes absolute
        try: 
            temp = urljoin(url, temp).split("#")[0] #removing the url fragment
            hyper_links.append(temp)
            
        except ValueError:
            print(f"Skipping malformed URL: {temp}")
            continue

    return hyper_links

def is_valid(url : str) -> bool:
    '''
    Decide whether to crawl this url or not. 

    If decide to crawl, return True; otherwise False

    Input:
        url(string): the potential URL to crawl
    Returns:
        boolean: True to crawl, False to not crawl
    '''
    # Valid Links: *.ics.uci.edu/*, *.cs.uci.edu/*, *.informatics.uci.edu/*, *.stat.uci.edu/*
    # using regex
    VALID_URL_RE = re.compile(r"^(?:[a-z0-9-]+\.)*(?:ics|cs|informatics|stat)\.uci\.edu$")

    try:
        parsed = urlparse(url)
        # check if URL is http or https / check if it's a link we want
        if parsed.scheme not in set(["http", "https"]) or not VALID_URL_RE.match(parsed.netloc): 
            return False

        # check if path is file extension
        if re.match( 
            r".*\.(css|js|bmp|gif|jpe?g|ico"
            + r"|png|tiff?|mid|mp2|mp3|mp4"
            + r"|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf"
            + r"|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names"
            + r"|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso"
            + r"|epub|dll|cnf|tgz|sha1"
            + r"|thmx|mso|arff|rtf|jar|csv"
            + r"|rm|smil|wmv|swf|wma|zip|rar|gz)$", parsed.path.lower()):
            return False
        
        # separating trap detection from basic url validation
        return True
    
    except (TypeError, ValueError, AttributeError):
        return False